import React, { useRef, useState } from 'react';

function Thoughts() {

  const current = new Date();
  const date = `${current.getDate()}/${current.getMonth()+1}/${current.getFullYear()}`;



  return (
    <div className="container-sm mt-5 bg-success form-outline mb-4">
      <div className="form-outline">
      <label className="form-label" htmlFor="date">Date</label>
        <input type={date} id="date" className="form-control" defaultValue={date}/>
      </div>
      <div className="form-outline">
        <label className="form-label" htmlFor="myThoughts">Input Thoughts</label>
        <textarea className="form-control" id="myThoughts" rows="4"></textarea>
      </div>
      <button type="button" className="btn btn-primary mt-3 mb-2">Save</button>
    </div>
  )
}

export default Thoughts
