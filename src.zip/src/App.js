import Thoughts from './components/Thoughts';
import './App.css';

function App() {
  return (
    <div>
      <Thoughts/>
    </div>
  );
}

export default App;
